/**
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.fineract.organisation.teller.domain;

import org.apache.fineract.organisation.teller.exception.TellerNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TellerRepositoryWrapper {

    private final TellerRepository repository;

    @Autowired
    public TellerRepositoryWrapper(final TellerRepository repository) {
        this.repository = repository;
    }

    @Transactional(readOnly = true)
    public Teller findOneWithNotFoundDetection(final Long id) {
        final Teller teller = this.repository.findById(id).orElseThrow(() -> new TellerNotFoundException(id));
        teller.initializeLazyCollections();
        return teller;
    }

    public Teller save(final Teller teller) {
        return this.repository.save(teller);
    }

    public Teller saveAndFlush(final Teller teller) {
        return this.repository.saveAndFlush(teller);
    }

    public void delete(final Teller teller) {
        this.repository.delete(teller);
    }
}
